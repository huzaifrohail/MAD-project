import React from "react";
import "./styles.css";
import Bmr from "./components/Bmr.js";
import "./components/Bmr.css";
function App() {
  return (
    <div className="App">
      <Bmr />
    </div>
  );
}

export default App;
